package com.spring.assignment7;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Component;
@Configuration
@ImportResource(locations = {"beans.xml"})
class Configurations{
	@Bean
	public Employeename employeename() {
		return new Employeename();
	}
}

class Employeename{
	@Value(value = "raj")
	String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}


}
class Employeeno{
	int no;

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}
}
@Component
class Employeeaddress{
	@Value(value = "hyd")
	String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
}
public class Employee {
	
	

	public static void main(String[] args) {
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		ctx.register(Configurations.class);
		ctx.scan("com.spring.assignment7");
		ctx.refresh();
		Employeeaddress address= ctx.getBean(Employeeaddress.class);
		Employeename employeename = ctx.getBean(Employeename.class);
		Employeeno employeeno = ctx.getBean(Employeeno.class);
		System.out.println(employeename.getName());
		System.out.println(address.getAddress());
		System.out.println(employeeno.getNo());
		

	}

}

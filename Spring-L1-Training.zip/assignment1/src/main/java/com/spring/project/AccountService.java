package com.spring.project;


public interface AccountService {
	double balanceEnquiry();
	void displayDetails();
}

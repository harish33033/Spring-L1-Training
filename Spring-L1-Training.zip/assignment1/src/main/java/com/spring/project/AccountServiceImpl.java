package com.spring.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
@Qualifier("accountserviceimpl")
public class AccountServiceImpl implements AccountService {
	@Autowired
	public Account account;
	public Account getaccount() {
		return account;
	}
	public double balanceEnquiry() {
		return account.getBalance();
	}
	public void displayDetails() {
		System.out.println(account.getAccountID()+" "+account.getActHoldername()+" "+account.getActHolderAddress().getCity()+" "
													+account.getBalance());
	}
}

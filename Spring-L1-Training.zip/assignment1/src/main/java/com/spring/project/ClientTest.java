package com.spring.project;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("com.spring.project")
class Configurations {
	@Bean
	public Account account() {
		return new Account(address());
	}
	@Bean
	public Address address() {
		return new Address();
	}
	@Bean
	public ClientTest clienttest() {
		return new ClientTest();
	}
}
public class ClientTest {
	@Autowired
	@Qualifier("accountserviceimpl")
	AccountServiceImpl accountservice;

	public static void main(String[] args) {
		Scanner c = new Scanner(System.in);
		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		ctx.scan("com.spring.project");
		ctx.refresh();
		ctx.register(Configurations.class);
		ClientTest a = ctx.getBean(ClientTest.class); 
		System.out.println("enter address datails hno,street,area,city,zipcode");
		a.accountservice.account.getActHolderAddress().setHno(c.nextInt());
		a.accountservice.account.getActHolderAddress().setStreet(c.next());
		a.accountservice.account.getActHolderAddress().setArea(c.next());
		a.accountservice.account.getActHolderAddress().setCity(c.next());
		a.accountservice.account.getActHolderAddress().setZipcode(c.nextInt());
		System.out.println("enter account details accountid,accountholder name,balance");
		a.accountservice.account.setAccountID(c.nextInt());
		a.accountservice.account.setActHoldername(c.next());
		a.accountservice.account.setBalance(c.nextDouble());
		a.accountservice.displayDetails();
		
		
	}

}

package com.spring.project;


public class Account {
	private int accountID;
	private String actHoldername;
	private double balance;
	private Address actHolderAddress;
	public Account(Address address) {
		this.actHolderAddress = address;
	}
	public int getAccountID() {
		return accountID;
	}
	public void setAccountID(int accountID) {
		this.accountID = accountID;
	}
	public String getActHoldername() {
		return actHoldername;
	}
	public void setActHoldername(String actHoldername) {
		this.actHoldername = actHoldername;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Address getActHolderAddress() {
		return actHolderAddress;
	}
	
	
}

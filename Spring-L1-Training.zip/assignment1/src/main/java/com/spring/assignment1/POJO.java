package com.spring.assignment1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

class Test implements POJI{
	String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void sayHai() {
		System.out.println("hai "+name);
		
	}
	
}
 class POJO  {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		POJI poji = (POJI) context.getBean("pojo");
		poji.sayHai();

	}

}

package com.spring.assignment1;

public interface POJI {
	public void sayHai();
}

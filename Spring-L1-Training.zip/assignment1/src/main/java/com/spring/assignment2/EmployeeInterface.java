package com.spring.assignment2;

public interface EmployeeInterface {
	

}

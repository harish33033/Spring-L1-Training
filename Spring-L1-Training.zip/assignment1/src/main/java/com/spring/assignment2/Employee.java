package com.spring.assignment2;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.assignment1.POJI;
class Employee1 implements EmployeeInterface {
	List addresslist;
	List projectlist;
	public List getAddresslist() {
		return addresslist;
	}
	public void setAddresslist(List addresslist) {
		this.addresslist = addresslist;
	}
	public List getProjectlist() {
		return projectlist;
	}
	public void setProjectlist(List projectlist) {
		this.projectlist = projectlist;
	}
	
}

public class Employee  {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		EmployeeInterface emp = (Employee1) context.getBean("employee1");
		System.out.println(((Employee1) emp).getProjectlist());
		System.out.println(((Employee1) emp).getAddresslist());
		
		

	}

}

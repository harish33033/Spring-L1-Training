package com.spring.assignment3;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


class Cycle implements InitializingBean, DisposableBean{
	String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	void sayhai() {
		System.out.println("hai "+name);
	}
	void init() {
		System.out.println("inside init method");
		
	}
	public void destroy() {
		System.out.println("inside destory method");
	}
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		//System.out.println("after properties set");
		
	}
}
class Child{
	String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	void sayHai() {
		
		System.out.println("hai child "+name);
	}
}

public class Lifecycle {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Cycle c = (Cycle) context.getBean("cycle");
		Child ch = (Child) context.getBean("child");
		c.sayhai();
		ch.sayHai();
		((AbstractApplicationContext) context).close();

	}

}

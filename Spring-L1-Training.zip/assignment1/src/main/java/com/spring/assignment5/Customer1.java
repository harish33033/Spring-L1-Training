package com.spring.assignment5;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Service
@Qualifier("address")
class Address{
	@Value(value = "straight to hyd")
	String route;

	public String getRoute() {
		return route;
	}

	public void setRoute(String route) {
		this.route = route;
	}	
	void sayhai() {
		System.out.println("hai");
	}
}
public class Customer1 {
	
	@Autowired
	@Qualifier("address")
	Address address1;

	public Address getAddress() {
		return address1;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		Customer1 c = (Customer1) context.getBean("customer1");
		c.getAddress().sayhai();
		//c.getAddress().setRoute(route);
		System.out.println(c.getAddress().getRoute());

	}
}
